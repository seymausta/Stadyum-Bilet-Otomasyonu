﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StadyumMenu
{
    public partial class anamenu : Form
    {
        public anamenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Form2 musteriform = new Form2();
            musteriform.MdiParent = this;
            musteriform.FormBorderStyle = FormBorderStyle.None;
            panel2.Controls.Add(musteriform);
            musteriform.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Form3 macform = new Form3();
            macform.MdiParent = this;
            macform.FormBorderStyle = FormBorderStyle.None;
            panel2.Controls.Add(macform);
            macform.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Form4 biletform = new Form4();
            biletform.MdiParent = this;
            biletform.FormBorderStyle = FormBorderStyle.None;
            panel2.Controls.Add(biletform);
            biletform.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
