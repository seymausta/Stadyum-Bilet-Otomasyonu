﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StadyumMenu
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        static SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-53U4TMB9\\SQLEXPRESS;Initial Catalog=stadyumveritabani;Integrated Security=True");
      
        
        SqlDataAdapter dapt = new SqlDataAdapter("Select *From musteri", baglanti);

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            string kayit = "update musteri set ad=@ad,soyad=@soyad,tel_no=@tel_no,e_posta=@e_posta where tc_no=@tc_no";
            // müşteri tablomuzun ilgili alanlarını değiştirecek olan güncelleme sorgusu.
            SqlCommand kmt = new SqlCommand(kayit, baglanti);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            kmt.Parameters.AddWithValue("@ad", textBox1.Text);
            kmt.Parameters.AddWithValue("@soyad", textBox2.Text);
            kmt.Parameters.AddWithValue("@tel_no", textBox4.Text);
            kmt.Parameters.AddWithValue("@e_posta", textBox5.Text);
            kmt.Parameters.AddWithValue("@tc_no", textBox6.Text);
            //Parametrelerimize Form üzerinde ki kontrollerden girilen verileri aktarıyoruz.
            kmt.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Müşteri Bilgileri Güncellendi.");
            textBox4.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox3.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            string kayit = "SELECT * from musteri where tc_no=@tc_no";
            SqlCommand kmt = new SqlCommand(kayit, baglanti);
            kmt.Parameters.AddWithValue("@tc_no", textBox3.Text);
            SqlDataAdapter da = new SqlDataAdapter(kmt);
            SqlDataReader dr = kmt.ExecuteReader();
            if (dr.Read()) //Sadece tek bir kayıt döndürüleceği için while kullanmadım.
            {
                textBox6.Text = dr["tc_no"].ToString();
                textBox1.Text = dr["ad"].ToString();
                textBox2.Text = dr["soyad"].ToString();
                textBox4.Text = dr["tel_no"].ToString();
                textBox5.Text = dr["e_posta"].ToString();

                //Datareader ile okunan verileri form kontrollerine aktardık.
            }
            else
            {
                MessageBox.Show("Müşteri Bulunamadı.");
                textBox3.Clear();
            }
                baglanti.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
