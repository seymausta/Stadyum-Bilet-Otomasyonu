﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StadyumMenu
{
    public partial class Form4 : Form
    {
        public int i;
        public Form4()
        {
            InitializeComponent();
        }

        static SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-53U4TMB9\\SQLEXPRESS;Initial Catalog=stadyumveritabani;Integrated Security=True");
      
        SqlCommand kmt;
        SqlDataAdapter dapt = new SqlDataAdapter("Select *From bilet", baglanti);

        void listele()
        {
            baglanti.Open();
            dapt = new SqlDataAdapter("Select *From bilet", baglanti);
            DataTable tablo = new DataTable();
            dapt.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Show();
            listele();
            textBox3.Clear();
            textBox1.Clear();
            textBox2.Clear();
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox4.Clear();
            i = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            i = 1;
            
            try
            { 
                    dataGridView1.Hide();
                    string sorgu = "Insert into bilet (mac_mac_id,musteri_tc_no,bilet_tur,tribun_tur,koltuk_no) values (@mac_mac_id,@musteri_tc_no,@bilet_tur,@tribun_tur,@koltuk_no)";
                    kmt = new SqlCommand(sorgu, baglanti);


                    kmt.Parameters.AddWithValue("@mac_mac_id", textBox1.Text);
                    kmt.Parameters.AddWithValue("@musteri_tc_no", textBox2.Text);
                    kmt.Parameters.AddWithValue("@bilet_tur", comboBox1.Text);
                    kmt.Parameters.AddWithValue("@tribun_tur", comboBox2.Text);
                    kmt.Parameters.AddWithValue("@koltuk_no", textBox4.Text);
                    baglanti.Open();
                    kmt.ExecuteNonQuery();
                    MessageBox.Show("Yeni bilet işlemi tamamlandı.");
                    baglanti.Close();
                    textBox3.Clear();
                    textBox1.Clear();
                    textBox2.Clear();
                    comboBox1.Text = "";
                    comboBox2.Text = "";
                    textBox4.Clear();
                



            }
            catch 
            {
                MessageBox.Show("Maç eklenemedi.");
               
                baglanti.Close();

            }




        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (i == 1)
            {

                textBox3.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                comboBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            }
        }

      

        private void button3_Click(object sender, EventArgs e)
        {
            i = 0;
            baglanti.Open();
            dapt = new SqlDataAdapter("Select *From mac", baglanti);
            DataTable tablo = new DataTable();
            dapt.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close(); 
        }
    }
}
