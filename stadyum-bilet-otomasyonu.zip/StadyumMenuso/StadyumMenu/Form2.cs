﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace StadyumMenu
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        static SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-53U4TMB9\\SQLEXPRESS;Initial Catalog=stadyumveritabani;Integrated Security=True");

        SqlCommand kmt;
        SqlDataAdapter dapt = new SqlDataAdapter("Select *From musteri", baglanti);

        void listele()
        {   // tablo.Clear();
            baglanti.Open();
            dapt = new SqlDataAdapter("Select *From musteri", baglanti);
            DataTable tablo = new DataTable();
            dapt.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sorgu = "Insert into musteri (tc_no,ad,soyad,tel_no,e_posta) values (@tc_no,@ad,@soyad,@tel_no,@e_posta)";
                kmt = new SqlCommand(sorgu, baglanti);
                kmt.Parameters.AddWithValue("@tc_no", textBox3.Text);
                kmt.Parameters.AddWithValue("@ad", textBox1.Text);
                kmt.Parameters.AddWithValue("@soyad", textBox2.Text);
                kmt.Parameters.AddWithValue("@tel_no", textBox4.Text);
                kmt.Parameters.AddWithValue("@e_posta", textBox5.Text);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                MessageBox.Show("Müşteri eklendi.");
                baglanti.Close();
                textBox3.Clear();
                textBox1.Clear();
                textBox2.Clear();
                textBox4.Clear();
                textBox5.Clear();
               
            }
            catch
            {
                MessageBox.Show("Lütfen geçerli bir T.C. No giriniz.");
                baglanti.Close();
                textBox3.Clear();
                

            }

        }                       
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 guncelle = new Form6();
            guncelle.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 silme = new Form5();
            silme.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            listele();
            textBox3.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }
    }
}
