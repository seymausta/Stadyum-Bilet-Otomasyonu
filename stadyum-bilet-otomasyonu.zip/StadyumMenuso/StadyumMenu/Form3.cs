﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StadyumMenu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        static SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-53U4TMB9\\SQLEXPRESS;Initial Catalog=stadyumveritabani;Integrated Security=True");
        //baglanti.Open();
        //baglanti.Close();
        SqlCommand kmt;
        SqlDataAdapter dapt = new SqlDataAdapter("Select *From mac", baglanti);

        void listele()
        {
            baglanti.Open();
            dapt = new SqlDataAdapter("Select *From mac", baglanti);
            DataTable tablo = new DataTable();
            dapt.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sorgu = "Insert into mac (takim1,takim2,tarih_saat) values (@takim1,@takim2,@tarih_saat)";
                kmt = new SqlCommand(sorgu, baglanti);
                kmt.Parameters.AddWithValue("@takim1", textBox1.Text);
                kmt.Parameters.AddWithValue("@takim2", textBox2.Text);
                kmt.Parameters.AddWithValue("@tarih_saat", dateTimePicker1.Value);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                MessageBox.Show("Maç bilgisi eklendi.");
                baglanti.Close();     // listeleme 3 ündede var
                textBox3.Clear();
                textBox1.Clear();
                textBox2.Clear();
            }
            catch 
            {
                MessageBox.Show("Maç eklenemedi.");
                baglanti.Close();
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            listele();
            textBox3.Clear();
            textBox1.Clear();
            textBox2.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            dateTimePicker1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            
        }

       
          
    }
}
